<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="apple-mobile-web-app-capable" content="yes" />
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
    <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, viewport-fit=cover" />
    <title>Azures BootStrap</title>
    <link rel="stylesheet" type="text/css" href="styles\bootstrap.css" />
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900|Roboto:300,300i,400,400i,500,500i,700,700i,900,900i&display=swap" rel="stylesheet" />
    <link rel="stylesheet" type="text/css" href="fonts\css\fontawesome-all.min.css" />
    <link rel="manifest" href="_manifest.json" data-pwa-version="set_in_manifest_and_pwa_js" />
    <link rel="apple-touch-icon" sizes="180x180" href="app\icons\icon-192x192.png" />
  </head>
  <body class="theme-light" data-highlight="blue2">
    <div id="preloader"><div class="spinner-border color-highlight" role="status"></div></div>
    <div id="page">
      <div class="header header-fixed header-auto-show header-logo-app">
        <a href="#" data-back-button="" class="header-title header-subtitle">Back to Pages</a>
        <a href="#" data-back-button="" class="header-icon header-icon-1"><i class="fas fa-arrow-left"></i></a>
        <a href="#" data-toggle-theme="" class="header-icon header-icon-2 show-on-theme-dark"><i class="fas fa-sun"></i></a>
        <a href="#" data-toggle-theme="" class="header-icon header-icon-2 show-on-theme-light"><i class="fas fa-moon"></i></a>
        <a href="#" data-menu="menu-highlights" class="header-icon header-icon-3"><i class="fas fa-brush"></i></a>
        <a href="#" data-menu="menu-main" class="header-icon header-icon-4"><i class="fas fa-bars"></i></a>
      </div>
      <div id="footer-bar" class="footer-bar-5">
        <a href="index-components.html"><i data-feather="heart" data-feather-line="1" data-feather-size="21" data-feather-color="red2-dark" data-feather-bg="red2-fade-light"></i><span>Features</span></a>
        <a href="index-media.html"><i data-feather="image" data-feather-line="1" data-feather-size="21" data-feather-color="green1-dark" data-feather-bg="green1-fade-light"></i><span>Media</span></a>
        <a href="index.html"><i data-feather="home" data-feather-line="1" data-feather-size="21" data-feather-color="blue2-dark" data-feather-bg="blue2-fade-light"></i><span>Home</span></a>
        <a href="index-pages.html" class="active-nav"><i data-feather="file" data-feather-line="1" data-feather-size="21" data-feather-color="brown1-dark" data-feather-bg="brown1-fade-light"></i><span>Pages</span></a>
        <a href="index-settings.html"><i data-feather="settings" data-feather-line="1" data-feather-size="21" data-feather-color="gray2-dark" data-feather-bg="gray2-fade-light"></i><span>Settings</span></a>
      </div>
      <div class="page-content">
        <div class="page-title page-title-large">
          <h2 data-username="Enabled!" class="greeting-text"></h2>
          <a href="#" data-menu="menu-main" class="bg-fade-gray1-dark shadow-xl preload-img" data-src="images/avatars/5s.png"></a>
        </div>
        <div class="card header-card shape-rounded" data-card-height="200">
          <div class="card-overlay bg-highlight opacity-95"></div>
          <div class="card-overlay dark-mode-tint"></div>
          <div class="card-bg preload-img" data-src="images/pictures/20s.jpg"></div>
        </div>
        
        <div class="content mt-n2">
          <div class="row mb-0">
            <a href="#" class="col-4">
              <div class="card card-style text-center py-3 mx-0 mb-0">
                <i class="fa fa-upload font-24 color-theme opacity-30"></i>
                <p class="font-13 font-500 mb-n1 mt-2 color-theme">Sale</p>
              </div>
            </a>
            <a href="#" class="col-4">
              <div class="card card-style text-center py-3 mx-0 mb-0">
                <i class="fa fa-download font-24 color-theme opacity-30"></i>
                <p class="font-13 font-500 mb-n1 mt-2 color-theme">Purchase</p>
              </div>
            </a>
            <a href="#" class="col-4">
              <div class="card card-style text-center py-3 mx-0 mb-0">
                <i class="fa fa-users font-24 color-theme opacity-30"></i>
                <p class="font-13 font-500 mb-n1 mt-2 color-theme">Customer</p>
              </div>
            </a>
          </div>
        </div>
        <div class="card card-style">
          <div class="content">
            <h3 class="float-left font-16">Recent Sales</h3>
            <a class="float-right font-12 color-highlight mt-n1" href="#">View All</a>
            <div class="clearfix"></div>
            
            <div class="d-flex">
              <div>
                <a href="#" class="icon icon-m bg-green1-dark rounded-m shadow-xl"><i class="fa fa-arrow-down"></i></a>
              </div>
              <div class="align-self-center pl-3">
                <h5 class="font-600 font-14 mb-n2">Envato Income</h5>
                <span class="color-theme font-11">Recieved via PayPal</span>
              </div>
              <div class="align-self-center ml-auto">
                <h5 class="color-green1-dark mb-n1 text-right">$12.350</h5>
                <span class="color-theme d-block font-11 text-right">Jul 15th</span>
              </div>
            </div>
            <div class="divider mt-3 mb-3"></div>
            <div class="d-flex">
              <div>
                <a href="#" class="icon icon-m bg-dark2-dark rounded-m shadow-xl"><i class="fab fa-apple font-20"></i></a>
              </div>
              <div class="align-self-center pl-3">
                <h5 class="font-600 font-14 mb-n2">Apple Music</h5>
                <span class="color-theme font-11">Monthly Subscription</span>
              </div>
              <div class="align-self-center ml-auto">
                <h5 class="color-yellow1-dark mb-n1 text-right">$12.350</h5>
                <span class="color-theme d-block font-11 text-right">Jul 15th</span>
              </div>
            </div>
            <div class="divider mt-3 mb-3"></div>
            <div class="d-flex">
              <div>
                <a href="#" class="icon icon-m bg-red2-dark rounded-m shadow-xl"><i class="fa fa-arrow-up font-20"></i></a>
              </div>
              <div class="align-self-center pl-3">
                <h5 class="font-600 font-14 mb-n2">Work Partner</h5>
                <span class="color-theme font-11">via VISA Card ****1234</span>
              </div>
              <div class="align-self-center ml-auto">
                <h5 class="color-red1-dark mb-n1 text-right">$1.350</h5>
                <span class="color-theme d-block font-11 text-right">Jul 15th</span>
              </div>
            </div>
            <div class="divider mt-3 mb-3"></div>
            <div class="d-flex">
              <div>
                <a href="#" class="icon icon-m bg-blue2-dark rounded-m shadow-xl"><i class="fa fa-exchange-alt font-20"></i></a>
              </div>
              <div class="align-self-center pl-3">
                <h5 class="font-600 font-14 mb-n2">Savings Account</h5>
                <span class="color-theme font-11">via VISA Card ****1234</span>
              </div>
              <div class="align-self-center ml-auto">
                <h5 class="color-blue2-dark mb-n1 text-right">$10.000</h5>
                <span class="color-theme d-block font-11 text-right">Jul 15th</span>
              </div>
            </div>
          </div>
        </div>
        <div class="card mt-4 preload-img" data-src="images/pictures/20s.jpg">
          <div class="card-body py-4">
            <h3 class="color-white mb-n1">Report</h3>
            <p class="color-white opacity-60">
              &nbsp;
            </p>
            <div class="card rounded-m mt-n3 mb-0">
              <div class="content mb-2 mt-3">
                <div class="d-flex">
                  <div class="pr-4 align-self-center">
                    <p class="font-600 color-highlight mb-0"></p>
                    <h1 class="mb-2">Daily Revenue</h1>
                  </div>
                  <div class="w-100 align-self-center pl-3">
                    <h6 class="font-14 font-500">Cash<span class="float-right color-green2-dark">+$3.115</span></h6>
                    <div class="divider mb-2 mt-1"></div>
                    <h6 class="font-14 font-500">Credit<span class="float-right color-red2-dark">-$1.315</span></h6>
                  </div>
                </div>
                <div class="divider mt-2 mb-3"></div>
                <div class="row mb-0">
                  
                  <div class="col-6 pr-1">
                    <div class="mx-0 mb-3">
                      <h6 class="font-13 font-400 mb-0">Morning</h6>
                      <h3 class="color-brown2-dark font-15 mb-0">+11.2%</h3>
                    </div>
                  </div>
                  <div class="col-6 pl-1">
                    <div class="mx-0 mb-3">
                      <h6 class="font-13 font-400 mb-0">Evening</h6>
                      <h3 class="color-blue2-dark font-15 mb-0">$14,500</h3>
                    </div>
                  </div>

                  <div class="col-6 pr-1">
                    <div class="mx-0 mb-3">
                      <h6 class="font-13 font-400 mb-0">Cow</h6>
                      <h3 class="color-green2-dark font-15 mb-0">+31.2%</h3>
                    </div>
                  </div>
                  <div class="col-6 pl-1">
                    <div class="mx-0 mb-3">
                      <h6 class="font-13 font-400 mb-0">Buffalo</h6>
                      <h3 class="color-red2-dark font-15 mb-0">-14.5%</h3>
                    </div>
                  </div>

                </div>
              </div>
            </div>
          </div>
          <div class="card-overlay bg-highlight opacity-95"></div>
          <div class="card-overlay dark-mode-tint"></div>
        </div>
        <!--<div class="card card-style">
          <div class="content">
            <h3 class="font-700">Pending Actions</h3>
            <p>
              Account or Payments that are currently being processed. We'll let you know as soon as it's done.
            </p>
            <div class="d-flex">
              <div class="align-self-center">
                <a href="#" class="icon icon-m bg-green1-dark rounded-m shadow-xl"><i class="fa fa-user"></i></a>
              </div>
              <div class="align-self-center pl-3">
                <h5 class="font-600 font-14 mb-0 mt-n1">Account Verification</h5>
                <p class="color-theme opacity-50 font-11 line-height-xs">Awaiting Confirmation Code Validation</p>
              </div>
            </div>
            <div class="divider mt-3 mb-3"></div>
            <div class="d-flex">
              <div class="align-self-center">
                <a href="#" class="icon icon-m bg-red2-dark rounded-m shadow-xl"><i class="fa fa-key"></i></a>
              </div>
              <div class="align-self-center pl-3">
                <h5 class="font-600 font-14 mb-0">Password Not Secure</h5>
                <p class="color-theme opacity-50 font-11 line-height-xs">We recommend Securing your Account with 2FA for better account security.</p>
              </div>
            </div>
          </div>
        </div>-->
        <div class="content mb-n2">
          <h5 class="float-left font-16 font-500">Top Credit Customer</h5>
          <a class="float-right font-12 color-highlight mt-n1" href="#">View All</a>
          <div class="clearfix"></div>
        </div>
        <div class="content">
          <div class="single-slider owl-carousel owl-no-dots">
            <div class="card card-style bg-20" data-card-height="180">
              <div class="card-top pl-3 pt-3">
                <h1 class="color-white font-19">Customer Name</h1>
              </div>
              <div class="card-center pr-3">
                <h4 class="color-white text-right">Mobile no</h4>
              </div>
              <div class="card-bottom pl-3 pb-2">
                <h5 class="color-white">Milk Type</h5>
              </div>
              <div class="card-bottom pr-3 pb-2">
                <h5 class="color-white float-right">Pending</h5>
              </div>
              <div class="card-overlay bg-gradient"></div>
            </div>
            <!--
            <div class="card card-style bg-1" data-card-height="180">
              <div class="card-top pl-3 pt-3">
                <h1 class="color-white">AMEX</h1>
              </div>
              <div class="card-center pr-3">
                <h4 class="color-white text-right">**** **** **** 3415</h4>
              </div>
              <div class="card-bottom pl-3 pb-2">
                <h5 class="color-white">John Runner</h5>
              </div>
              <div class="card-bottom pr-3 pb-2">
                <h5 class="color-white float-right">03/25</h5>
              </div>
              <div class="card-overlay bg-gradient"></div>
            </div>
            <div class="card card-style bg-6" data-card-height="180">
              <div class="card-top pl-3 pt-3">
                <h1 class="color-white">Visa</h1>
              </div>
              <div class="card-center pr-3">
                <h4 class="color-white text-right">**** **** **** 3456</h4>
              </div>
              <div class="card-bottom pl-3 pb-2">
                <h5 class="color-white">Jane Louder</h5>
              </div>
              <div class="card-bottom pr-3 pb-2">
                <h5 class="color-white float-right">05/24</h5>
              </div>
              <div class="card-overlay bg-gradient"></div>
            </div>-->
          </div>
        </div>

        <div class="footer" data-menu-load="menu-footer.html"></div>
      </div>

      <div id="menu-share" class="menu menu-box-bottom menu-box-detached rounded-m" data-menu-load="menu-share.html" data-menu-height="420" data-menu-effect="menu-over"></div>
      <div id="menu-highlights" class="menu menu-box-bottom menu-box-detached rounded-m" data-menu-load="menu-colors.html" data-menu-height="510" data-menu-effect="menu-over"></div>
      <div id="menu-main" class="menu menu-box-right menu-box-detached rounded-m" data-menu-width="260" data-menu-load="menu-main.html" data-menu-active="nav-pages" data-menu-effect="menu-over"></div>
    </div>
    <script type="text/javascript" src="scripts\jquery.js"></script>
    <script type="text/javascript" src="scripts\bootstrap.min.js"></script>
    <script type="text/javascript" src="scripts\custom.js"></script>
  </body>
</html>
